package com.helpdesk.model;

public enum Role {
    CUSTOMER, STAFF, ADMIN
}
