package com.helpdesk.controller;

import com.helpdesk.dto.Dtos.StatusRequest;
import com.helpdesk.dto.Dtos.TicketResponse;
import com.helpdesk.service.TicketService;
import com.helpdesk.service.UserService;
import jakarta.validation.Valid;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/** Support Staff module: view assigned tickets, update status, resolve. */
@RestController
@RequestMapping("/api/staff")
public class StaffController {

    private final TicketService ticketService;
    private final UserService userService;

    public StaffController(TicketService ticketService, UserService userService) {
        this.ticketService = ticketService;
        this.userService = userService;
    }

    @GetMapping("/tickets")
    public List<TicketResponse> assigned(Authentication auth) {
        return ticketService.assignedTo(userService.getByEmail(auth.getName()));
    }

    @PutMapping("/tickets/{id}/status")
    public TicketResponse updateStatus(Authentication auth, @PathVariable Long id,
                                       @Valid @RequestBody StatusRequest req) {
        return ticketService.updateStatus(userService.getByEmail(auth.getName()), id, req.status());
    }
}
