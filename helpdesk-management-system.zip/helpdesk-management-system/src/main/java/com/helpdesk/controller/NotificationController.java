package com.helpdesk.controller;

import com.helpdesk.dto.Dtos.NotificationResponse;
import com.helpdesk.service.NotificationService;
import com.helpdesk.service.UserService;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/** Notification module: in-app notifications for every role. */
@RestController
@RequestMapping("/api/notifications")
public class NotificationController {

    private final NotificationService notifications;
    private final UserService userService;

    public NotificationController(NotificationService notifications, UserService userService) {
        this.notifications = notifications;
        this.userService = userService;
    }

    @GetMapping
    public List<NotificationResponse> mine(Authentication auth) {
        return notifications.mine(userService.getByEmail(auth.getName()));
    }

    @GetMapping("/unread-count")
    public Map<String, Long> unreadCount(Authentication auth) {
        return Map.of("unread", notifications.unreadCount(userService.getByEmail(auth.getName())));
    }

    @PutMapping("/{id}/read")
    public NotificationResponse markRead(Authentication auth, @PathVariable Long id) {
        return notifications.markRead(userService.getByEmail(auth.getName()), id);
    }
}
