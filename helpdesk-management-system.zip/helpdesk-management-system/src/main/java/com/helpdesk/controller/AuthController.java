package com.helpdesk.controller;

import com.helpdesk.dto.Dtos.RegisterRequest;
import com.helpdesk.dto.Dtos.UserResponse;
import com.helpdesk.service.UserService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

/** Customer registration / login module. Login = HTTP Basic; GET /me checks the credentials. */
@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final UserService userService;

    public AuthController(UserService userService) {
        this.userService = userService;
    }

    @PostMapping("/register")
    @ResponseStatus(HttpStatus.CREATED)
    public UserResponse register(@Valid @RequestBody RegisterRequest req) {
        return UserResponse.of(userService.register(req));
    }

    @GetMapping("/me")
    public UserResponse me(Authentication auth) {
        return UserResponse.of(userService.getByEmail(auth.getName()));
    }
}
