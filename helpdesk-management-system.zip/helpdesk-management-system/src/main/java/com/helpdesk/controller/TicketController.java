package com.helpdesk.controller;

import com.helpdesk.dto.Dtos.*;
import com.helpdesk.service.TicketService;
import com.helpdesk.service.UserService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/** Customer + Ticket Management modules. Role checks are in SecurityConfig and TicketService. */
@RestController
@RequestMapping("/api/tickets")
public class TicketController {

    private final TicketService ticketService;
    private final UserService userService;

    public TicketController(TicketService ticketService, UserService userService) {
        this.ticketService = ticketService;
        this.userService = userService;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public TicketResponse create(Authentication auth, @Valid @RequestBody CreateTicketRequest req) {
        return ticketService.create(userService.getByEmail(auth.getName()), req);
    }

    @GetMapping("/my")
    public List<TicketResponse> myTickets(Authentication auth) {
        return ticketService.myTickets(userService.getByEmail(auth.getName()));
    }

    @GetMapping("/{id}")
    public TicketResponse get(Authentication auth, @PathVariable Long id) {
        return ticketService.get(userService.getByEmail(auth.getName()), id);
    }

    @GetMapping("/{id}/comments")
    public List<CommentResponse> comments(Authentication auth, @PathVariable Long id) {
        return ticketService.comments(userService.getByEmail(auth.getName()), id);
    }

    @PostMapping("/{id}/comments")
    @ResponseStatus(HttpStatus.CREATED)
    public CommentResponse addComment(Authentication auth, @PathVariable Long id,
                                      @Valid @RequestBody CommentRequest req) {
        return ticketService.addComment(userService.getByEmail(auth.getName()), id, req);
    }
}
