package com.helpdesk.controller;

import com.helpdesk.dto.Dtos.*;
import com.helpdesk.model.Status;
import com.helpdesk.service.TicketService;
import com.helpdesk.service.UserService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/** Admin module: manage users, assign tickets, monitor all requests, generate reports. */
@RestController
@RequestMapping("/api/admin")
public class AdminController {

    private final TicketService ticketService;
    private final UserService userService;

    public AdminController(TicketService ticketService, UserService userService) {
        this.ticketService = ticketService;
        this.userService = userService;
    }

    // ----- users -----
    @GetMapping("/users")
    public List<UserResponse> users() {
        return userService.all().stream().map(UserResponse::of).toList();
    }

    @PostMapping("/users")
    @ResponseStatus(HttpStatus.CREATED)
    public UserResponse createUser(@Valid @RequestBody CreateUserRequest req) {
        return UserResponse.of(userService.createUser(req));
    }

    @PutMapping("/users/{id}/active")
    public UserResponse setActive(@PathVariable Long id, @RequestParam boolean value) {
        return UserResponse.of(userService.setActive(id, value));
    }

    // ----- tickets -----
    @GetMapping("/tickets")
    public List<TicketResponse> tickets(@RequestParam(required = false) Status status) {
        return ticketService.all(status);
    }

    @PutMapping("/tickets/{id}/assign")
    public TicketResponse assign(@PathVariable Long id, @Valid @RequestBody AssignRequest req) {
        return ticketService.assign(id, req.staffId());
    }

    @PutMapping("/tickets/{id}/status")
    public TicketResponse updateStatus(Authentication auth, @PathVariable Long id,
                                       @Valid @RequestBody StatusRequest req) {
        return ticketService.updateStatus(userService.getByEmail(auth.getName()), id, req.status());
    }

    // ----- reports -----
    @GetMapping("/reports")
    public ReportResponse report() {
        return ticketService.report();
    }
}
