package com.helpdesk.service;

import com.helpdesk.dto.Dtos.*;
import com.helpdesk.model.Role;
import com.helpdesk.model.User;
import com.helpdesk.repository.UserRepository;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@Service
@Transactional
public class UserService {

    private final UserRepository users;
    private final PasswordEncoder encoder;

    public UserService(UserRepository users, PasswordEncoder encoder) {
        this.users = users;
        this.encoder = encoder;
    }

    /** Public self-registration: always creates a CUSTOMER. */
    public User register(RegisterRequest req) {
        return create(req.name(), req.email(), req.password(), Role.CUSTOMER);
    }

    /** Admin creates a STAFF / ADMIN / CUSTOMER account. */
    public User createUser(CreateUserRequest req) {
        return create(req.name(), req.email(), req.password(), req.role());
    }

    private User create(String name, String email, String rawPassword, Role role) {
        String normalized = email.trim().toLowerCase();
        if (users.existsByEmail(normalized)) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Email already registered");
        }
        User u = new User();
        u.setName(name.trim());
        u.setEmail(normalized);
        u.setPassword(encoder.encode(rawPassword));
        u.setRole(role);
        return users.save(u);
    }

    @Transactional(readOnly = true)
    public User getById(Long id) {
        return users.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "User not found: " + id));
    }

    @Transactional(readOnly = true)
    public User getByEmail(String email) {
        return users.findByEmail(email.trim().toLowerCase())
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "User not found"));
    }

    @Transactional(readOnly = true)
    public List<User> byRole(Role role) {
        return users.findByRole(role);
    }

    @Transactional(readOnly = true)
    public List<User> all() {
        return users.findAll();
    }

    public User setActive(Long id, boolean active) {
        User u = getById(id);
        u.setActive(active);
        return users.save(u);
    }
}
