package com.helpdesk.service;

import com.helpdesk.dto.Dtos.*;
import com.helpdesk.model.*;
import com.helpdesk.repository.CommentRepository;
import com.helpdesk.repository.TicketRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Service
@Transactional
public class TicketService {

    private final TicketRepository tickets;
    private final CommentRepository comments;
    private final UserService userService;
    private final NotificationService notifications;

    public TicketService(TicketRepository tickets, CommentRepository comments,
                         UserService userService, NotificationService notifications) {
        this.tickets = tickets;
        this.comments = comments;
        this.userService = userService;
        this.notifications = notifications;
    }

    // ---------- Customer ----------
    public TicketResponse create(User customer, CreateTicketRequest req) {
        Ticket t = new Ticket();
        t.setTitle(req.title().trim());
        t.setDescription(req.description().trim());
        t.setPriority(req.priority() == null ? Priority.MEDIUM : req.priority());
        t.setCreatedBy(customer);
        t = tickets.save(t);

        for (User admin : userService.byRole(Role.ADMIN)) {
            notifications.notify(admin, "New ticket #" + t.getId() + " created by "
                    + customer.getName() + ": " + t.getTitle());
        }
        return TicketResponse.of(t);
    }

    @Transactional(readOnly = true)
    public List<TicketResponse> myTickets(User customer) {
        return tickets.findByCreatedByOrderByCreatedAtDesc(customer).stream().map(TicketResponse::of).toList();
    }

    // ---------- Support staff ----------
    @Transactional(readOnly = true)
    public List<TicketResponse> assignedTo(User staff) {
        return tickets.findByAssignedToOrderByCreatedAtDesc(staff).stream().map(TicketResponse::of).toList();
    }

    // ---------- Admin ----------
    @Transactional(readOnly = true)
    public List<TicketResponse> all(Status status) {
        List<Ticket> list = (status == null)
                ? tickets.findAllByOrderByCreatedAtDesc()
                : tickets.findByStatusOrderByCreatedAtDesc(status);
        return list.stream().map(TicketResponse::of).toList();
    }

    public TicketResponse assign(Long ticketId, Long staffId) {
        Ticket t = find(ticketId);
        if (t.getStatus() == Status.RESOLVED) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Ticket is already resolved");
        }
        User staff = userService.getById(staffId);
        if (staff.getRole() != Role.STAFF || !staff.isActive()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Selected user is not an active support staff");
        }
        t.setAssignedTo(staff);
        t.setStatus(Status.IN_PROGRESS);
        t = tickets.save(t);

        notifications.notify(staff, "Ticket #" + t.getId() + " has been assigned to you: " + t.getTitle());
        notifications.notify(t.getCreatedBy(), "Your ticket #" + t.getId() + " was assigned to "
                + staff.getName() + " and is now IN_PROGRESS");
        return TicketResponse.of(t);
    }

    @Transactional(readOnly = true)
    public ReportResponse report() {
        Map<String, Long> byPriority = new LinkedHashMap<>();
        for (Priority p : Priority.values()) {
            byPriority.put(p.name(), tickets.countByPriority(p));
        }
        double avgMinutes = tickets.findByStatus(Status.RESOLVED).stream()
                .filter(t -> t.getResolvedAt() != null)
                .mapToLong(t -> Duration.between(t.getCreatedAt(), t.getResolvedAt()).toMinutes())
                .average()
                .orElse(0);
        double avgHours = Math.round(avgMinutes / 60.0 * 100.0) / 100.0;

        return new ReportResponse(
                tickets.count(),
                tickets.countByStatus(Status.OPEN),
                tickets.countByStatus(Status.IN_PROGRESS),
                tickets.countByStatus(Status.RESOLVED),
                byPriority,
                avgHours);
    }

    // ---------- Shared: view, status, comments ----------
    @Transactional(readOnly = true)
    public TicketResponse get(User user, Long id) {
        Ticket t = find(id);
        checkAccess(user, t);
        return TicketResponse.of(t);
    }

    /** Staff may set IN_PROGRESS / RESOLVED on their own tickets; admin may set any status. */
    public TicketResponse updateStatus(User actor, Long id, Status newStatus) {
        Ticket t = find(id);

        if (actor.getRole() == Role.STAFF) {
            if (t.getAssignedTo() == null || !t.getAssignedTo().getId().equals(actor.getId())) {
                throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Ticket is not assigned to you");
            }
            if (newStatus == Status.OPEN) {
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                        "Staff can only set IN_PROGRESS or RESOLVED");
            }
        } else if (actor.getRole() != Role.ADMIN) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Customers cannot change ticket status");
        }

        if (newStatus == Status.IN_PROGRESS && t.getAssignedTo() == null) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Assign the ticket to a staff member first");
        }
        if (t.getStatus() == newStatus) {
            return TicketResponse.of(t);
        }

        t.setStatus(newStatus);
        t.setResolvedAt(newStatus == Status.RESOLVED ? LocalDateTime.now() : null);
        t = tickets.save(t);

        String text = (newStatus == Status.RESOLVED)
                ? "Your ticket #" + t.getId() + " has been RESOLVED"
                : "Your ticket #" + t.getId() + " status changed to " + newStatus;
        notifications.notify(t.getCreatedBy(), text);
        return TicketResponse.of(t);
    }

    public CommentResponse addComment(User author, Long ticketId, CommentRequest req) {
        Ticket t = find(ticketId);
        checkAccess(author, t);
        if (t.getStatus() == Status.RESOLVED) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Ticket is resolved; comments are closed");
        }

        Comment c = new Comment();
        c.setTicket(t);
        c.setAuthor(author);
        c.setMessage(req.message().trim());
        c = comments.save(c);

        if (author.getRole() == Role.CUSTOMER) {
            if (t.getAssignedTo() != null) {
                notifications.notify(t.getAssignedTo(), "Customer replied on ticket #" + t.getId());
            }
        } else {
            notifications.notify(t.getCreatedBy(), author.getName() + " replied on your ticket #" + t.getId());
        }
        return CommentResponse.of(c);
    }

    @Transactional(readOnly = true)
    public List<CommentResponse> comments(User user, Long ticketId) {
        Ticket t = find(ticketId);
        checkAccess(user, t);
        return comments.findByTicketOrderByCreatedAtAsc(t).stream().map(CommentResponse::of).toList();
    }

    // ---------- helpers ----------
    private Ticket find(Long id) {
        return tickets.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Ticket not found: " + id));
    }

    private void checkAccess(User user, Ticket t) {
        boolean allowed = switch (user.getRole()) {
            case ADMIN -> true;
            case STAFF -> t.getAssignedTo() != null && t.getAssignedTo().getId().equals(user.getId());
            case CUSTOMER -> t.getCreatedBy().getId().equals(user.getId());
        };
        if (!allowed) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "You cannot access this ticket");
        }
    }
}
