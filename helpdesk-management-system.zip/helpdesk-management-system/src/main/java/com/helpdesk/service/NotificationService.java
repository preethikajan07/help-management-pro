package com.helpdesk.service;

import com.helpdesk.dto.Dtos.NotificationResponse;
import com.helpdesk.model.Notification;
import com.helpdesk.model.User;
import com.helpdesk.repository.NotificationRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

/**
 * Notification module: every event is stored as an in-app notification and,
 * when helpdesk.mail.enabled=true and SMTP is configured, also sent by email.
 */
@Service
@Transactional
public class NotificationService {

    private static final Logger log = LoggerFactory.getLogger(NotificationService.class);

    private final NotificationRepository repo;
    private final ObjectProvider<JavaMailSender> mailSender;

    @Value("${helpdesk.mail.enabled:false}")
    private boolean mailEnabled;

    @Value("${helpdesk.mail.from:no-reply@helpdesk.local}")
    private String from;

    public NotificationService(NotificationRepository repo, ObjectProvider<JavaMailSender> mailSender) {
        this.repo = repo;
        this.mailSender = mailSender;
    }

    public void notify(User recipient, String message) {
        Notification n = new Notification();
        n.setRecipient(recipient);
        n.setMessage(message.length() > 500 ? message.substring(0, 497) + "..." : message);
        repo.save(n);
        sendEmail(recipient, message);
    }

    @Transactional(readOnly = true)
    public List<NotificationResponse> mine(User user) {
        return repo.findByRecipientOrderByCreatedAtDesc(user).stream().map(NotificationResponse::of).toList();
    }

    @Transactional(readOnly = true)
    public long unreadCount(User user) {
        return repo.countByRecipientAndSeenFalse(user);
    }

    public NotificationResponse markRead(User user, Long id) {
        Notification n = repo.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Notification not found"));
        if (!n.getRecipient().getId().equals(user.getId())) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Not your notification");
        }
        n.setSeen(true);
        return NotificationResponse.of(repo.save(n));
    }

    private void sendEmail(User to, String message) {
        if (!mailEnabled) {
            return;
        }
        JavaMailSender sender = mailSender.getIfAvailable();
        if (sender == null) {
            log.warn("helpdesk.mail.enabled=true but no SMTP (spring.mail.host) is configured");
            return;
        }
        try {
            SimpleMailMessage mail = new SimpleMailMessage();
            mail.setFrom(from);
            mail.setTo(to.getEmail());
            mail.setSubject("Helpdesk notification");
            mail.setText(message);
            sender.send(mail);
        } catch (Exception e) {
            log.warn("Could not send email to {}: {}", to.getEmail(), e.getMessage());
        }
    }
}
