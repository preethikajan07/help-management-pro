package com.helpdesk.repository;

import com.helpdesk.model.Priority;
import com.helpdesk.model.Status;
import com.helpdesk.model.Ticket;
import com.helpdesk.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface TicketRepository extends JpaRepository<Ticket, Long> {

    List<Ticket> findByCreatedByOrderByCreatedAtDesc(User customer);

    List<Ticket> findByAssignedToOrderByCreatedAtDesc(User staff);

    List<Ticket> findAllByOrderByCreatedAtDesc();

    List<Ticket> findByStatusOrderByCreatedAtDesc(Status status);

    List<Ticket> findByStatus(Status status);

    long countByStatus(Status status);

    long countByPriority(Priority priority);
}
