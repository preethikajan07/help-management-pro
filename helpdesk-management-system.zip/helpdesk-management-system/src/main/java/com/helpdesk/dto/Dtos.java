package com.helpdesk.dto;

import com.helpdesk.model.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.time.LocalDateTime;
import java.util.Map;

/** All request / response objects used by the REST API. */
public final class Dtos {

    private Dtos() {}

    // ---------------- Requests ----------------

    public record RegisterRequest(
            @NotBlank @Size(max = 100) String name,
            @NotBlank @Email @Size(max = 150) String email,
            @NotBlank @Size(min = 6, max = 100) String password) {}

    public record CreateUserRequest(
            @NotBlank @Size(max = 100) String name,
            @NotBlank @Email @Size(max = 150) String email,
            @NotBlank @Size(min = 6, max = 100) String password,
            @NotNull Role role) {}

    public record CreateTicketRequest(
            @NotBlank @Size(max = 200) String title,
            @NotBlank @Size(max = 2000) String description,
            Priority priority) {}

    public record AssignRequest(@NotNull Long staffId) {}

    public record StatusRequest(@NotNull Status status) {}

    public record CommentRequest(@NotBlank @Size(max = 1000) String message) {}

    // ---------------- Responses ----------------

    public record UserResponse(Long id, String name, String email, Role role, boolean active) {
        public static UserResponse of(User u) {
            return new UserResponse(u.getId(), u.getName(), u.getEmail(), u.getRole(), u.isActive());
        }
    }

    public record TicketResponse(
            Long id,
            String title,
            String description,
            Priority priority,
            Status status,
            String createdBy,
            String assignedTo,
            LocalDateTime createdAt,
            LocalDateTime updatedAt,
            LocalDateTime resolvedAt) {

        public static TicketResponse of(Ticket t) {
            return new TicketResponse(
                    t.getId(),
                    t.getTitle(),
                    t.getDescription(),
                    t.getPriority(),
                    t.getStatus(),
                    t.getCreatedBy().getName(),
                    t.getAssignedTo() == null ? null : t.getAssignedTo().getName(),
                    t.getCreatedAt(),
                    t.getUpdatedAt(),
                    t.getResolvedAt());
        }
    }

    public record CommentResponse(
            Long id, Long ticketId, String author, Role authorRole, String message, LocalDateTime createdAt) {

        public static CommentResponse of(Comment c) {
            return new CommentResponse(
                    c.getId(),
                    c.getTicket().getId(),
                    c.getAuthor().getName(),
                    c.getAuthor().getRole(),
                    c.getMessage(),
                    c.getCreatedAt());
        }
    }

    public record NotificationResponse(Long id, String message, boolean read, LocalDateTime createdAt) {
        public static NotificationResponse of(Notification n) {
            return new NotificationResponse(n.getId(), n.getMessage(), n.isSeen(), n.getCreatedAt());
        }
    }

    public record ReportResponse(
            long totalTickets,
            long open,
            long inProgress,
            long resolved,
            Map<String, Long> byPriority,
            double avgResolutionHours) {}
}
